package com.util;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.By;

public class Locators {

private static HashMap<String,String> locators= null;
	
	public static By get(String key)
	{
		if (locators == null)
		{
			locators = new HashMap<String,String>();
			
			Properties p = new Properties();
					
					try{
						p.load(new FileReader(new File("locators.properties")));
					}
		catch (Exception e){
			
			for (Object k : p.keySet()){
				
				locators.put((String) k , p.getProperty((String)k));
			}
		}
		
			String value  = locators.get(key);
			return By.xpath(value);
			
		}
		return null;
		
	}
}