package com.page;

import com.base.BasePage;
import com.util.Locators;
import com.util.PageDriver;

public class ContactPage extends BasePage {

	
	public ContactPage(PageDriver driver)
	{
		super(driver);
	}

public void sendContact(String name, String email,String phone,String message)
{
	driver.findElement(Locators.get("wbqa.cp.fullname")).sendKeys(name);
	driver.findElement(Locators.get("wbqa.cp.email")).sendKeys(email);
	driver.findElement(Locators.get("wbqa.cp.phone")).sendKeys(phone);
	driver.findElement(Locators.get("wbqa.cp.message")).sendKeys(message);
    
	driver.findElement(Locators.get("wbqa.cp.submit")).click();

}

public void clearContact()
{
	driver.findElement(Locators.get("wbqa.cp.clearfullname")).clear();
	driver.findElement(Locators.get("wbqa.cp.clearfullname")).clear();
	driver.findElement(Locators.get("wbqa.cp.fullname")).clear();
	driver.findElement(Locators.get("wbqa.cp.fullname")).clear();

}




}
