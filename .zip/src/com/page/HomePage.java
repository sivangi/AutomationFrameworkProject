package com.page;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.base.BasePage;
import com.util.PageDriver;

public class HomePage extends BasePage{
	
	public HomePage(PageDriver driver)
	{
		super(driver);
	}

	public void gotoHome()
	{
		driver.get("http://www.whiteboxqa.com");
	}
	
	
	public String getHeader()
	{
		return driver.findElement(By.xpath(".//*[@id='logo']")).getText().trim();
		
	}
	
	public List<String> getButtons()
	{
	List<String> buttons = new ArrayList<String>();
	
	for(WebElement element : driver.findElements(By.cssSelector(".pull-right.social-icons>li")))
	{
		buttons.add(element.getText().trim());
	}
	return buttons;
}

	public void gotoContactPage()
	{
WebElement info = driver.findElement(By.partialLinkText("Info"));
	    
	    Actions action = new Actions((WebDriver) driver);
	    action.moveToElement(info).build().perform();
	    
	   WebElement contact=driver.findElement(By.xpath(".//*[@id='navbar-collapse']/ul/li[6]/ul/li[2]/a"));
	    contact.click();
	}
	
	
}
