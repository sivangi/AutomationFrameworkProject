package com.test;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

import com.base.BaseTest;
import com.page.HomePage;
import com.util.PageDriver;

public class HomePageTest extends BaseTest{
	

	HomePage homePage;
	PageDriver driver;
	
	
	@BeforeMethod
	public void setUp()
	{
		homePage = new HomePage(this.driver);
	}
	
	
	
	public void testHeader()
	{
		String header = homePage.getHeader();
		Assert.assertEquals(header,"whiteboxqa");
		
	}

	public void testLinks()
	{
		List<String> buttons = homePage.getButtons();
		assertTrue(buttons.contains("Contact"));	
	
}



	private void assertTrue(boolean contains) {
		// TODO Auto-generated method stub
		
	}
}