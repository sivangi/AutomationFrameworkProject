package com.test;


import org.testng.annotations.Test;

import com.base.BaseTest;
import com.page.ContactPage;
import com.page.HomePage;

public class ContactTest extends BaseTest{
  
	HomePage homePage;
	ContactPage contactPage;
	
public void beforeClass()
	
	{
		homePage = new HomePage(driver);
		contactPage = new ContactPage(driver);
	}
	
	
	public Object[][] contactTestData(){
		
		return new Object[][]{
				
				{  "X","x@gmail.com","555-555-5555","Hello!"},
				{  "X","x@gmail.com","555-555-5555","Hello!"},
				{  "X","x@gmail.com","555-555-5555","Hello!"},
				{  "X","x@gmail.com","555-555-5555","Hello!"}
				};
	}
	

	@Test
	 public void testContact(String name,String email,String phone,String message)
	 {
		 homePage.gotoHome();
		 homePage.gotoContactPage();
		 contactPage.sendContact(name,email,phone,message);
	 }
	
	
	

}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	