package com.base;

import com.util.PageDriver;

public abstract class BasePage {
	
	public PageDriver driver;
	public static String baseUrl;
	
	public BasePage(PageDriver driver)
	
	{
		this.driver = driver;
	}

}