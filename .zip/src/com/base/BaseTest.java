package com.base;

import java.util.HashMap;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeSuite;

import com.util.Configuration;
import com.util.PageDriver;

public abstract class BaseTest {
	       
	protected	PageDriver driver;
		
		
		@BeforeSuite
		public void setUp()throws Exception
		
		{
			HashMap<String,String> config = Configuration.loadSettings();
			
			
			if(config.get("browser").equals("fireFox"))
			{
				driver.driver= new FirefoxDriver();
			}
			if(config.get("browser").equals("chrome"))
			{
				driver.driver= new ChromeDriver();
			}
			if(config.get("browser").equals("ie"))
			{
				driver.driver= new InternetExplorerDriver();
			}
			if(config.get("browser").equals("fireFox"))
			{
				driver.driver= new FirefoxDriver();
			}
		
		BasePage.baseUrl = config.get("url");
		
		}
		
		
		
		
		
}